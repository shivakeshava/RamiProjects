export class Transactions{
    tid:string;
    taccount_sender:string;
    taccount_reciver:string;
    tamount:string;
    ttype:string;
  
  
      constructor(tid:string,taccount_sender:string,taccount_reciver:string,tamount:string,ttype:string)
      {
        this.tid=tid;
        this.taccount_sender=taccount_sender;
        this.taccount_reciver=taccount_reciver;
        this.tamount=tamount;
        this.ttype=ttype;
      }
  }