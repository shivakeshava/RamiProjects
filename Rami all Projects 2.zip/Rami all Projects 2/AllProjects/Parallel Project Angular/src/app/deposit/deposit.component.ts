import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/Models/Customer';
import { Transactions } from 'src/Models/Transactions';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  isLogin:boolean=true;
  customers:Customer[]=[];
  createdTransaction:Transactions;
  router:Router;

  service:ServiceService;
  constructor(service:ServiceService,router:Router) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
    this.router=router;
  }


  
  depositeAmount(data:any){
    let tid:number;
    let caccount_first=data.caccount;
    let cbalance=data.cbalance;
    var ttype:string;
    ttype="Deposite Amount"
    this.service.depositeBalance(caccount_first,cbalance);
    this.createdTransaction=new Transactions("123",data.caccount,"",data.cbalance,ttype);
    this.service.addTransaction(this.createdTransaction)
    this.router.navigate(['view']);
  }

  ngOnInit() {
    this.customers=this.service.getCustomers();
  }
}
