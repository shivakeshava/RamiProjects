import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';

import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { CashTransferComponent } from './cash-transfer/cash-transfer.component';
import { TransactionsComponent } from './transactions/transactions.component';
import { ViewComponent } from './view/view.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    
    DepositComponent,
    WithdrawComponent,
    ShowBalanceComponent,
    CashTransferComponent,
    TransactionsComponent,
    ViewComponent,
    SignUpComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
